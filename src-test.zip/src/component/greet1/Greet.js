const Greet = (props) => {
  return <div>hello {props.name}</div>;
};
export default Greet;
