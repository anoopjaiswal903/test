import React from "react";

export const Skills = () => {
  const names = ["abc", "bcd", "sjs"];
  return (
    <div>
      <ul>
        {names.map((n) => {
          return <li key={n}>{n}</li>;
        })}
      </ul>
    </div>
  );
};
