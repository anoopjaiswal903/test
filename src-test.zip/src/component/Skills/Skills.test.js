import { screen, render } from "@testing-library/react";
import { Skills } from "./Skills";

describe("skills", () => {
  const nameCheck = ["anoop", "sujit", "uday"];

  test("render correctly", () => {
    render(<Skills name={nameCheck} />);
    const listElement = screen.getByRole("list");
    expect(listElement).toBeInTheDocument();
  });

  test("render a list name", () => {
    render(<Skills name={nameCheck} />);
    const lisItemElment = screen.getAllByRole("listitem");
    expect(lisItemElment).toHaveLength(nameCheck.length);
  });
});
