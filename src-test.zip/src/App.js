import "./App.css";
import Application from "./component/Applications/Application";

function App() {
  return (
    <div className="App">
      <Application />
    </div>
  );
}

export default App;
